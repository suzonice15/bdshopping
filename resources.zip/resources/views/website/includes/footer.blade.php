

<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-7">
                <div class="footer-delivery-adreess"><h3><a href="http://dhakabaazar.com/">Bdshopping zone.</a></h3><span><a
                                href="{{url('/')}}/">Home</a></span> <span><a href="{{url('/')}}/about">About</a></span>
                    <span><a href="{{url('/')}}/return-policy">Return Policy</a></span> <span><a
                                href="{{url('/')}}/terms-and-conditions">Terms & Conditions</a></span> <span><a
                                href="{{url('/')}}/sitemap">Sitemapp</a></span> <br> <span class="adreess"> 39 /a Islami Somaj Kollan Mosjid Goli Senpara Mirpur 10 Dhaka-1216</span>

                </div>
                <div class="footer-delivery-adreess"><h3 style="color:#F2F2F2;">Payment</h3> <span><a
                                href="http://dhakabaazar.com/replacementpolicy">Replacement Policy</a></span> <span><a
                                href="http://dhakabaazar.com/refundpolicy">Refund Policy</a></span> <span><a
                                href="http://dhakabaazar.com/customercomplain">Complain</a></span>
                    <div class="footer-border"></div>
                </div>
                <div class="footer-p-delivery-adreess">
                    <div class="footer-delivery-adreess"><h3 style="color:#F2F2F2;">We Accept</h3> <span
                                style="text-align:center;">Cash On Delivery</span> <span><img
                                    src="http://dhakabaazar.com/images/footer-cod.png" alt=""></span> <span><img
                                    src="http://dhakabaazar.com/images/footer-bkash.png" alt=""></span> <span><img
                                    src="http://dhakabaazar.com/images/footer-bdbl.png" alt=""></span> <span><img
                                    src="http://dhakabaazar.com/images/footer-visa.png" alt=""></span> <span><img
                                    src="http://dhakabaazar.com/images/footer-mastercard.png" alt=""></span> <span><img
                                    src="http://dhakabaazar.com/images/amex.png" alt="#"></span>
                        <div class="footer-border"></div>
                    </div>
                </div>
                <div class="footer-andorid-app">
                    <div class="footer-andorid-content"><h3>Bdshopping zone. is a best online shopping site in
                            bangladesh </h3>
                        <p>Bdshopping zone. an online shopping destination where you can shop the widest selection of
                            electronics & Security Products, home appliances more in Bangladesh Follow us on Facebook
                            and Twitter to stay updated on the latest offers and Bdshopping zone. Products. Happy
                            shopping!.</p></div>
                    <div class="footer-andorid-button"></div>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="fotter-right-area">
                    <div class="news-letter"><h3>Newsletter</h3>
                        <p>To get our latest updates please subscribe now.</p></div>
                    <div class="footer-search-button">
                        <form id="newsletter" method="post"><input type="text" name="footer_newsletter_email"
                                                                   id="footer_newsletter_email">
                            <button>Subscribe</button>
                        </form>
                    </div>
                    <div class="footer-ques-complain">
                        <div class="thuumbnail"><a href="#"><span><img
                                            src="http://dhakabaazar.com/images/footer-ques.png" alt="#"> Question</span></a> <a
                                    href="#"><span><img src="http://dhakabaazar.com/images/footer-opinion.png" alt="#"> Comment</span></a>
                            <a href="#"><span><img src="http://dhakabaazar.com/images/footer-complain.png" alt="#"> Complain</span></a>
                        </div>
                    </div>
                    <div class="footer-phone-number"><span> <font>Phone</font>: +88078-2154242 </span> <span> <font>Email</font>: bdshopping@gmail.com </span>
                        <span> <font>Inbox</font>: <a href="https://www.facebook.com/dhakabaazarbd/">https://www.facebook.com/bdshopping/</a><br> </span>
                    </div>
                    <div class="footer-social-icon"><span class="fb_icon"><a class="facebook social-icon"
                                                                             href="https://www.facebook.com/dhakabaazarbd/"
                                                                             title="Facebook" target="_blank"> <i
                                        class="fa fa-facebook"></i> </a></span> <span class="tw_icon"><a
                                    href="https://twitter.com/dhakabaazar"><i class="fa fa-twitter"></i> </a></span> <span
                                class="gp_icon"><a href="https://plus.google.com/u/0/105163760293150281771"><i
                                        class="fa fa-google-plus"></i></a> </span> <span class="lk_icon"><a href="#"><i
                                        class="fa fa-linkedin"></i></a> </span> <span class="in_icon"><a href="#"><i
                                        class="fa fa-instagram"></i></a> </span></div>
                    <div class="footer-copyright"><span>© Copyright- Bdshopping zone 2020 || Powered By <a
                                    href="https://www.dhakabaazar.com/" target="_blank">Bdshopping zone.</a><br><br></span></div>
                </div>
            </div>
        </div>
        <br>
        <div class="footer-border"></div>

    </div>
</footer>
<aside id="minicart">
    <div class="closeCartBox cart-close"><i class="fa fa-chevron-right"></i></div>
    <div class="innerbox">
        <table class="table table-striped table-bordered">
            <tr>
                <td colspan="3" class="cart-heading"><span class="itemno">0</span> ITEMS</td>
            </tr>
            <tr>
                <td colspan="3" class="cart-action"><a href="https://www.dhakabaazar.com/" style="width:100%">Shop
                        Now</a></td>
            </tr>
        </table>
    </div>
</aside>
<div class="mobail_calling_option">
    <div class="fbchatbtn"></div>
    <a href="tel:+8801970778457" class="hotlinemp" rel="nofollow">
        <div class="mypage-alo-phone" style="">
            <div class="animated infinite zoomIn mypage-alo-ph-circle"></div>
            <div class="animated infinite pulse mypage-alo-ph-circle-fill"></div>
            <div class="animated infinite tada mypage-alo-ph-img-circle"></div>
        </div>
    </a></div> <!--zia end edith ----> <!-- facebook login sdk -->


<a id="gotop"><i class="fa fa-chevron-circle-up "></i></a>
{{--<div class="social-allway-ontop">--}}
    {{--<div id="close_social"><span class="fa fa-times-circle" title="Share"></span></div>--}}
    {{--<ul>--}}
        {{--<li class="facebook social-icon"><a class="facebook social-icon" href="https://www.facebook.com/dhakabaazarbd/"--}}
                                            {{--title="Facebook" target="_blank"> <i class="glyphicon glyphicon-search"> </a></li>--}}
        {{--<li class="twitter social-icon"><a class="twitter social-icon" href="https://twitter.com/dhakabaazar"--}}
                                           {{--title="Twitter" target="_blank"> <i class="fa fa-twitter"></i> </a></li>--}}
        {{--<li class="youtube social-icon"><a class="youtube social-icon"--}}
                                           {{--href="https://www.youtube.com/channel/UC6hCfmCPjL7Vfj_pUdByNFA/featured?view_as=subscriber"--}}
                                           {{--title="Youtube" target="_blank"> <i class="fa fa-youtube"></i> </a></li>--}}
        {{--<li class="instagram social-icon"><a class="instagram social-icon" href="https://www.instagram.com/dhakabaazar/"--}}
                                             {{--title="Instagram" target="_blank"> <i class="fa fa-instagram"></i> </a>--}}
        {{--</li>--}}
    {{--</ul>--}}
{{--</div>--}}
<script type="text/javascript" src="http://code.jquery.com/ui/1.10.2/jquery-ui.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/jquery.plugin.min.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/jquery.number.min.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/jquery.validate.min.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/jquery.easing.min.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/jquery.touchSwipe.min.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/flipclock.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/jquery.liquid-slider.min.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/jquery.cookie.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/jquery.tweet.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/jquery.prettyPhoto.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/zoomsl-3.0.min.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/retina.min.js"></script>
<script type="text/javascript" src="{{ asset('assets/font_end/')}}/js/custom.js"></script>
<script type="text/javascript" src="{{ asset('assets/font_end/')}}/js/mycustom.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/custom_product.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/elevatezoom.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/lightslider.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/jquery.countdown.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/scroller.js"></script>
<script type="text/javascript" src="https://www.dhakabaazar.com/js/owl.carousel.js"></script>


<script>
    $(document).on('click','.add_to_cart',function () {
        let product_id=  $(this).data("product_id"); // will return the number 123
        let picture=  $(this).data("picture"); // will return the number 123


        let quntity =$('#product_qty').val();

        if(typeof quntity ==='undefined'){
            quntity=1;
        } else {
            quntity=quntity;
        }

        $.ajax({
            type:"GET",
            url:"{{url('add-to-cart')}}?product_id="+product_id+"&picture="+picture+"&quntity="+quntity,

            success:function(data)
            {


//                $('body .count').text(data.result.count);
//                $('.total-price .value').text(data.result.total);
                console.log(data);

                $('span.itemno').text(data.result.count);
                //jQuery('header .cartbtn .total span.price').text(response.current_cart_total);
            }
        })

    })
</script>
<script>
    $(document).on('click','.buy_now',function () {
        let product_id=  $(this).data("product_id"); // will return the number 123
        let picture=  $(this).data("picture"); // will return the number 123
        let quntity =$('#product_qty').val();

        if(typeof quntity ==='undefined'){
            quntity=1;
        } else {
            quntity=quntity;
        }
        $.ajax({
            type:"GET",
            url:"{{url('add-to-cart')}}?product_id="+product_id+"&picture="+picture+"&quntity="+quntity,
            success:function(data)
            {
                window.location.assign("{{ url('/') }}/checkout")
                $('body .count').text(data.result.count);
                $('body .value').text(data.result.total);
            }
        })

    })
</script>
<script type="text/javascript">

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    jQuery('#search_query2').on('input change',function () {
        var search_query=$(this).val();


        if (search_query.length >= 1) {


            jQuery.ajax({
                type:"POST",
                url: "{{url('/')}}/home/product_search",
                data:{search:search_query},
                success:function(data)
                {


                    jQuery(".remove_class").hide();

                    jQuery('body .product_search').html(data);

                }
            });
        } else {
            jQuery(".remove_class").show();
            jQuery('body .product_search').html('');
        }
    });


    $(document).ready(function () {
        var window_width = $(window).width();

        if (window_width <= 999) {
            //alert('fff');
            jQuery('.home .catproducts .col-sm-3.desktop').remove();
            jQuery('.home .catproducts .col-sm-9').addClass('col-sm-12');
            jQuery('.home .catproducts .col-sm-12').removeClass('col-sm-9');
        }

        var no_of_items = 4;
        var live_no_of_items = 3;
        if (window_width <= 375) {
            no_of_items = 1;
            live_no_of_items = 1;
        }
        else if (window_width <= 767) {
            no_of_items = 2;
            live_no_of_items = 2;
        }

        $(".lightSlider").lightSlider({
            item: no_of_items,
            auto: true,
            loop: true,
            keyPress: true,
            pager: false,
            pauseOnHover: true,
            slideMargin: 0,
            autoWidth: false,
        });

        $("#liveShoppingLightSlider").lightSlider({
            item: live_no_of_items,
            auto: true,
            loop: true,
            keyPress: true,
            pager: false,
            pauseOnHover: true,
            slideMargin: 0,
            autoWidth: false,

        });
        $('#lightSlider').lightSlider({
            gallery: true,
            item: 1,
            loop: true,
            slideMargin: 0,
            thumbItem: 9
        });
    });


    $("#zoom_09").elevateZoom({
        gallery: "gallery_09",
        galleryActiveClass: "active"
    });

    /*### live shopping countdown ###*/
    //var newYear = new Date('December 30, 2017 04:00:00');
    var newYear = new Date('November 01, 2020 24:00:00');
    jQuery('#countdown').countdown({until: newYear});
</script>
</body>
</html>