 <a href="{{url('/')}}/customer/dasboard">My Profile</a>
 <a href="{{url('/')}}/customer/orders">My Orders</a>
 <a href="{{url('/')}}/customer/points">My Point </a>
 <a href="{{url('/')}}/customer/changed_password">Changed Password</a>
 <a href="{{url('/')}}/customer/logout">Logout </a>